package com.comp301.a04junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.comp301.a04junit.adventure.Direction;
import com.comp301.a04junit.adventure.Position;
import com.comp301.a04junit.adventure.PositionImpl;

import org.junit.Assert;
import org.junit.Test;

/** Write unit tests for the PositionImpl class here */
public class AdeptPositionTests {
  @Test
  public void constructorTest1() {
    int xTest = 7;
    int yTest = 11;
    Position positionTest = new PositionImpl(xTest, yTest);
    assertEquals(xTest, positionTest.getX());
    assertEquals(yTest, positionTest.getY());
  }
  @Test
  public void xGetterTest() {
    int xTest = 26;
    Position positionTest = new PositionImpl(xTest, 47);
    int xFirstCall = positionTest.getX();
    int xSecondCall = positionTest.getX();
    assertEquals(xTest, xFirstCall);
    assertEquals(xTest, xSecondCall);
    assertEquals(xFirstCall, xSecondCall);
  }
  @Test
  public void yGetterTest() {
    int yTest = 47;
    Position positionTest = new PositionImpl(24, yTest);
    int yFirstCall = positionTest.getY();
    int ySecondCall = positionTest.getY();
    assertEquals(yTest, yFirstCall);
    assertEquals(yTest, ySecondCall);
    assertEquals(yFirstCall, ySecondCall);
  }
  @Test
  public void getNeighborEastTest() {
    Position positionTest = new PositionImpl(2, 4);
    Position neighborPositionTest = positionTest.getNeighbor(Direction.EAST);
    assertEquals(neighborPositionTest.getX(), positionTest.getX()+1);
    assertEquals(neighborPositionTest.getY(), positionTest.getY());
  }
  @Test
  public void getNeighborNorthTest() {
    Position positionTest = new PositionImpl(2, 4);
    Position neighborPositionTest = positionTest.getNeighbor(Direction.NORTH);
    assertEquals(neighborPositionTest.getX(), positionTest.getX());
    assertEquals(neighborPositionTest.getY(), positionTest.getY()+1);
  }
  @Test
  public void getNeighborWestTest() {
    Position positionTest = new PositionImpl(2, 4);
    Position neighborPositionTest = positionTest.getNeighbor(Direction.WEST);
    assertEquals(neighborPositionTest.getX(), positionTest.getX()-1);
    assertEquals(neighborPositionTest.getY(), positionTest.getY());
  }
  @Test
  public void getNeighborSouthTest() {
    Position positionTest = new PositionImpl(2, 4);
    Position neighborPositionTest = positionTest.getNeighbor(Direction.SOUTH);
    assertEquals(neighborPositionTest.getX(), positionTest.getX());
    assertEquals(neighborPositionTest.getY(), positionTest.getY()-1);
  }
}
