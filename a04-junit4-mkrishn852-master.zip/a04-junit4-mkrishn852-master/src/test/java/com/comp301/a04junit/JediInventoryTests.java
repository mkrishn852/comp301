package com.comp301.a04junit;

import com.comp301.a04junit.adventure.Item;
import com.comp301.a04junit.adventure.ItemImpl;
import com.comp301.a04junit.adventure.Inventory;
import com.comp301.a04junit.adventure.InventoryImpl;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/** Write unit tests for the InventoryImpl class here */
public class JediInventoryTests {
  @Test
  public void constructorTest1() {
    List<Item> items = new ArrayList<>();
    Inventory inventoryTest = new InventoryImpl();
    assertEquals(items, inventoryTest.getItems());
  }
  @Test
  public void isEmptyTest1() {
    Inventory inventoryTest = new InventoryImpl();
    assertTrue(inventoryTest.getItems().isEmpty());
  }
  @Test
  public void getItemsTest1() {
    List<Item> items = new ArrayList<>();
    items.add(new ItemImpl("test 1"));
    items.add(new ItemImpl("test 2"));
    Inventory inventoryTest = new InventoryImpl();
    for (Item i : items) {
      inventoryTest.addItem(i);
    }
    assertArrayEquals(items.toArray(), inventoryTest.getItems().toArray());
  }
  @Test
  public void getItemsTest2() {
    Inventory inventoryTest = new InventoryImpl();
    inventoryTest.addItem(new ItemImpl("test 1"));
    List<Item> itemTest1 = inventoryTest.getItems();
    inventoryTest.addItem(new ItemImpl("test 2"));
    List<Item> itemTest2 = inventoryTest.getItems();
    assertNotEquals(itemTest1, itemTest2);
  }
  @Test
  public void getNumItemsTest1() {
    Inventory inventoryTest = new InventoryImpl();
    assertEquals(0, inventoryTest.getNumItems());
  }
  @Test
  public void addItemTest1() {
    List<Item> itemListTest = new ArrayList<>();
    itemListTest.add(new ItemImpl("test item 1"));
    Inventory inventoryTest = new InventoryImpl();
    inventoryTest.addItem(itemListTest.get(0));
    assertEquals(itemListTest, inventoryTest.getItems());
  }
  @Test
  public void removeItemTest1() {
    List<Item> itemListTest = new ArrayList<>();
    itemListTest.add(new ItemImpl("test item 1"));
    Inventory inventoryTest = new InventoryImpl();
    inventoryTest.addItem(itemListTest.get(0));
    itemListTest.add(new ItemImpl("test item 2"));
    inventoryTest.addItem(itemListTest.get(1));
    inventoryTest.removeItem(itemListTest.get(0));
    itemListTest.remove(0);
    Item removableItem = new ItemImpl("test item 3");
    inventoryTest.addItem(removableItem);
    inventoryTest.removeItem(removableItem);
    assertEquals(itemListTest, inventoryTest.getItems());
  }
  @Test
  public void clearTest1() {
    // clear an empty inventory
    Inventory inventoryTest = new InventoryImpl();
    inventoryTest.clear();
    assertTrue(inventoryTest.isEmpty());
  }
  @Test
  public void clearTest2() {
    // clear a non-empty inventory
    Inventory inventoryTest = new InventoryImpl();
    inventoryTest.addItem(new ItemImpl("test item"));
    inventoryTest.clear();
    assertTrue(inventoryTest.isEmpty());
  }
  @Test
  public void transferFromTest1() {
    Inventory inventoryTest1 = new InventoryImpl();
    Inventory inventoryTest2 = new InventoryImpl();
    inventoryTest2.addItem(new ItemImpl("test item"));
    inventoryTest1.transferFrom(inventoryTest2);
    assertTrue(inventoryTest2.isEmpty());
    assertFalse(inventoryTest1.isEmpty());
  }
  @Test
  public void transferFromTest2() {
    Inventory inventoryTest = new InventoryImpl();
    inventoryTest.addItem(new ItemImpl("test item"));
    inventoryTest.transferFrom(null);
    assertNotNull(inventoryTest.getItems());
  }
}
