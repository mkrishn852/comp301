package com.comp301.a04junit;

import com.comp301.a04junit.adventure.Item;
import com.comp301.a04junit.adventure.ItemImpl;

import org.junit.Test;

import static org.junit.Assert.*;

/** Write unit tests for the ItemImpl class here */
public class  AdeptItemTests {
  @Test
  public void constructorTest1() {
    String lower_string = "test";
    String upper_string = "Test";
    Item lowerTestItem = new ItemImpl(lower_string);
    Item upperTestItem = new ItemImpl(upper_string);
    assertEquals(lower_string, lowerTestItem.toString());
    assertEquals(upper_string, upperTestItem.toString());
  }
  @Test
  public void equalsTest1() {
    Item lowerTestItem = new ItemImpl("test");
    Item upperTestItem = new ItemImpl("Test");
    assertFalse(lowerTestItem.equals(upperTestItem));
  }
  @Test
  public void equalsTest2() {
    Item emptyTestItem = new ItemImpl("");
    Item otherTestItem = new ItemImpl("test");
    assertFalse(emptyTestItem.equals(otherTestItem));
  }
  @Test
  public void equalsTest3() {
    Item testItemOne = new ItemImpl("test");
    String test = "test";
    Item testItemTwo = new ItemImpl(test);
    assertTrue(testItemOne.equals(testItemTwo));
  }
  @Test
  public void equalsTest4() {
    Item TestItem = new ItemImpl("test");
    assertFalse(TestItem.equals(null));
  }
}