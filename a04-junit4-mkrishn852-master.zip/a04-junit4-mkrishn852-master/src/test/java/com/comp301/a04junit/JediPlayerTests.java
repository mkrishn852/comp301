package com.comp301.a04junit;

import com.comp301.a04junit.adventure.*;

import org.junit.Test;

import static org.junit.Assert.*;

/** Write unit tests for the PlayerImpl class here */
public class JediPlayerTests {
  @Test
  public void constructorTest1() {
    try {
    Player playerTest = new PlayerImpl(null, 0, 0);
    fail();
    } catch (IllegalArgumentException e) {
    }
  }
  @Test
  public void getNameTest() {
    String nameTest = "test name";
    Player playerTest = new PlayerImpl(nameTest, 0, 0);
    assertEquals(nameTest, playerTest.getName());
  }
  @Test
  public void getPositionTest() {
    Position positionTest = new PositionImpl(7, 8);
    Player playerTest = new PlayerImpl("test name", 7, 8);
    assertEquals(positionTest.getX(), playerTest.getPosition().getX());
    assertEquals(positionTest.getY(), playerTest.getPosition().getY());
  }
  @Test
  public void getInventoryTest() {
    Player playerTest = new PlayerImpl("test name", 7, 8);
    Inventory inventoryTest = new InventoryImpl();
    inventoryTest.addItem(new ItemImpl("test 1"));
    inventoryTest.addItem(new ItemImpl("test 2"));
    playerTest.getInventory().addItem(new ItemImpl("test 1"));
    playerTest.getInventory().addItem(new ItemImpl("test 2"));
    assertEquals(inventoryTest.getItems(), playerTest.getInventory().getItems());
  }
  @Test
  public void moveNorthTest() {
    Player playerTest = new PlayerImpl("test movement", 10, 15);
    // Player playerTestNorth = new PlayerImpl("test north", 10, 16);
    playerTest.move(Direction.NORTH);
    assertEquals(playerTest.getPosition().getX(), 10);
    assertEquals(playerTest.getPosition().getY(), 16);
  }
  @Test
  public void moveEastTest() {
    Player playerTest = new PlayerImpl("test movement", 10, 15);
    // Player playerTestEast = new PlayerImpl("test east", 11, 15);
    playerTest.move(Direction.EAST);
    assertEquals(playerTest.getPosition().getX(), 11);
    assertEquals(playerTest.getPosition().getY(), 15);
  }
  @Test
  public void moveSouthTest() {
    Player playerTest = new PlayerImpl("test movement", 10, 15);
    // Player playerTestSouth = new PlayerImpl("test south", 10, 14);
    playerTest.move(Direction.SOUTH);
    assertEquals(playerTest.getPosition().getX(), 10);
    assertEquals(playerTest.getPosition().getY(), 14);
  }
  @Test
  public void moveWestTest() {
    Player playerTest = new PlayerImpl("test movement", 10, 15);
    Player playerTestWest = new PlayerImpl("test west", 9, 15);
    playerTest.move(Direction.WEST);
    assertEquals(playerTest.getPosition().getX(), 9);
    assertEquals(playerTest.getPosition().getY(), 15);
  }
}
