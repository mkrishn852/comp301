package com.comp301.a04junit;

import com.comp301.a04junit.alphabetizer.Alphabetizer;

import org.junit.Assert;
import org.junit.Test;

import java.util.NoSuchElementException;

import static org.junit.Assert.*;

/** Write tests for the Alphabetizer class here */
public class NoviceAlphabetizerTests {

  @Test
  public void constructorTest1() {
    // Test to verify that constructor performs parameter validation
    Alphabetizer alpha = new Alphabetizer(null);
    assertNotNull(alpha);
  }
  @Test
  public void constructorTest2() {
    // Test verifies that constructor makes private copy of array
    Alphabetizer alphabetizedArray = new Alphabetizer(new String[]{"b1", "c1", "a1"});
    String[] ordered_array = new String[]{"a1", "b1", "c1"};
    for (String i : ordered_array) {
      assertEquals(i, alphabetizedArray.next());
    }
  }
  @Test
  public void constructorTest3() {
    // uppercase array
    Alphabetizer upperAlpha = new Alphabetizer(new String[]{"A", "C", "B"});
    String[] upperArray = new String[]{"A", "B", "C"};
    for (String i : upperArray) {
      assertTrue(upperAlpha.hasNext());
      assertEquals(i, upperAlpha.next());
    }
  }
  @Test
  public void nextTest1() {
    // Test that next() throws the right exception type when there are no more elements.
    Alphabetizer alphabetizedArray = new Alphabetizer(new String[]{"b1", "c1", "a1"});
    try {
      alphabetizedArray.next();
      alphabetizedArray.next();
      alphabetizedArray.next();
      alphabetizedArray.next();
      fail();
    }
    catch (NoSuchElementException e) { }
  }
  @Test
  public void hasNextTest1() {
    Alphabetizer alphabetizedArray = new Alphabetizer(new String[]{"b1", "c1", "a1"});
    if (alphabetizedArray.next() == null) {
      assertFalse(alphabetizedArray.hasNext());
    }
  }
  @Test
  public void hasNextTest2() {
    String[] mixedCapitalArray = new String[]{"bat", "Apple", "cat"};
    Alphabetizer alphabetizedArray = new Alphabetizer(mixedCapitalArray);
    if (alphabetizedArray.next() == null) {
      assertFalse(alphabetizedArray.hasNext());
    }
  }
  @Test
  public void hasNextTest3() {
    Alphabetizer nullAlphabet = new Alphabetizer(null);
    assertFalse(nullAlphabet.hasNext());
  }
  @Test
  public void mutationTest() {
    String[] intoAlpha = new String[]{"b", "c", "a"};
    Alphabetizer alphabetized = new Alphabetizer(intoAlpha);
    assertTrue(alphabetized.hasNext());
    assertEquals(intoAlpha[0], "b");
    assertTrue(alphabetized.hasNext());
    assertEquals(intoAlpha[1], "c");
    assertTrue(alphabetized.hasNext());
    assertEquals(intoAlpha[2], "a");
  }
}
