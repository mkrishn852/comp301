package com.comp301.a04junit.adventure;

/**
 * You do not have to make changes to this file for a04-junit. This file represents a class that you
 * should write tests for. You are not required to implement this class yourself. See the readme for
 * instructions on what this class is supposed to do.
 */
public class ItemImpl implements Item {
  private String name;

  public ItemImpl(String name) {
    // CODE OMITTED
  }

  @Override
  public String getName() {
    return null; // CODE OMITTED
  }

  @Override
  public boolean equals(Object other) {
    return false; // CODE OMITTED
  }

  @Override
  public String toString() {
    return null; // CODE OMITTED
  }
}
