package com.comp301.a04junit.adventure;

public enum Direction {
  NORTH,
  SOUTH,
  EAST,
  WEST
}
