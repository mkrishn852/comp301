package com.comp301.a04junit.adventure;

/**
 * You do not have to make changes to this file for a04-junit. This file represents a class that you
 * should write tests for. You are not required to implement this class yourself. See the readme for
 * instructions on what this class is supposed to do.
 */
public class PositionImpl implements Position {
  private int x;
  private int y;

  public PositionImpl(int x, int y) {
    // CODE OMITTED
  }

  public int getX() {
    return 0; // CODE OMITTED
  }

  public int getY() {
    return 0; // CODE OMITTED
  }

  @Override
  public Position getNeighbor(Direction direction) {
    return null; // CODE OMITTED
  }
}
