package com.comp301.a07pizza;

import static com.comp301.a07pizza.Cheese.BLEND;
import static com.comp301.a07pizza.Cheese.MOZZARELLA;
import static com.comp301.a07pizza.Crust.*;
import static com.comp301.a07pizza.Sauce.PESTO;
import static com.comp301.a07pizza.Sauce.TOMATO;
import static com.comp301.a07pizza.Topping.*;

public class PizzaFactory {

  public PizzaFactory() {}

  public static Pizza makeCheesePizza(Pizza.Size size) {
    Topping[] toppings = {};
    return new PizzaImpl(size, HAND_TOSSED, TOMATO, BLEND, toppings);
  }

  public static Pizza makeHawaiianPizza(Pizza.Size size) {
    Topping[] toppings = {HAM, PINEAPPLE};
    return new PizzaImpl(size, HAND_TOSSED, TOMATO, BLEND, toppings);
  }

  public static Pizza makeMeatLoversPizza(Pizza.Size size) {
    Topping[] toppings = {PEPPERONI, SAUSAGE, BACON, GROUND_BEEF};
    return new PizzaImpl(size, DEEP_DISH, TOMATO, BLEND, toppings);
  }

  public static Pizza makeVeggieSupremePizza(Pizza.Size size) {
    Topping[] toppings = {SUN_DRIED_TOMATO, GREEN_PEPPER, MUSHROOMS, OLIVES};
    return new PizzaImpl(size, THIN, TOMATO, BLEND, toppings);
  }

  public static Pizza makeDailySpecialPizza() {
    Topping[] toppings = {MUSHROOMS, OLIVES, GREEN_PEPPER, JALAPENO, ONION, BUFFALO_CHICKEN};
    return new PizzaImpl(Pizza.Size.MEDIUM, THIN, PESTO, MOZZARELLA, toppings);
  }
}
