package com.comp301.a07pizza;

import java.util.ArrayList;
import java.util.List;

public class PizzaImpl implements Pizza {
  private Size size;
  private Crust crust;
  private Sauce sauce;
  private Cheese cheese;
  private Topping[] toppings;

  public PizzaImpl(Size size, Crust crust, Sauce sauce, Cheese cheese, Topping[] toppings) {
    this.size = size;
    this.crust = crust;
    this.sauce = sauce;
    this.cheese = cheese;
    this.toppings = toppings;
  }

  @Override
  public boolean isVegetarian() {
    if (this.crust.isVegetarian()) {
      if (this.sauce.isVegetarian()) {
        if (this.cheese.isVegetarian()) {
          for (Topping topping : this.toppings) {
            if (!topping.isVegetarian()) {
              return false;
            }
          }
          return true;
        }
      }
    }
    return false;
  }

  @Override
  public boolean isVegan() {
    if (this.crust.isVegan()) {
      if (this.sauce.isVegan()) {
        if (this.cheese.isVegan()) {
          for (Topping topping : this.toppings) {
            if (!topping.isVegan()) {
              return false;
            }
          }
          return true;
        }
      }
    }
    return false;
  }

  @Override
  public double getPrice() {
    double price = 0;
    if (size == Size.SMALL) {
      price += 7.00;
      price += (this.toppings.length) * 0.25;
    }
    if (size == Size.MEDIUM) {
      price += 9.00;
      price += (this.toppings.length) * 0.50;
    }
    if (size == Size.LARGE) {
      price += 11.00;
      price += (this.toppings.length) * 0.75;
    }
    return price;
  }

  @Override
  public Size getSize() {
    return this.size;
  }

  @Override
  public Ingredient getSauce() {
    return this.sauce;
  }

  @Override
  public Ingredient getCheese() {
    return this.cheese;
  }

  @Override
  public Ingredient getCrust() {
    return this.crust;
  }

  @Override
  public Ingredient[] getToppings() {
    return this.toppings;
  }

  @Override
  public Ingredient[] getIngredients() {
    Ingredient[] ingredientArray = new Ingredient[toppings.length + 3];
    for (int i = 0; i < toppings.length; i++) {
      ingredientArray[i] = this.toppings[i];
    }
    ingredientArray[toppings.length] = cheese;
    ingredientArray[toppings.length + 1] = crust;
    ingredientArray[toppings.length + 2] = sauce;
    return ingredientArray;
  }
}
