package com.comp301.a05driver;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ProximityIterator implements Iterator<Driver> {
    private Iterator<Driver> iterator;
    private Position clientPosition;
    private int proximityRange;
    private Driver nextDriver;

    public ProximityIterator(Iterable<Driver> driverPool, Position clientPosition, int proximityRange) {
        if ((driverPool == null) || (clientPosition == null) || (proximityRange <= 0)) {
            throw new IllegalArgumentException();
        }
        this.iterator = driverPool.iterator();
        this.clientPosition = clientPosition;
        this.proximityRange = proximityRange;
        this.nextDriver = null;
    }

    private void loadDriver() {
        if (nextDriver != null) {
            }
        else {
            while (iterator.hasNext()) {
                Driver driver = iterator.next();
                if (clientPosition.getManhattanDistanceTo(driver.getVehicle().getPosition()) <= this.proximityRange) {
                    nextDriver = driver;
                    break;
                }
            }
        }
    }

    @Override
    public boolean hasNext() {
        loadDriver();
        return nextDriver != null;
    }

    @Override
    public Driver next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        Driver localDriver = this.nextDriver;
        this.nextDriver = null;
        return localDriver;
    }
}
