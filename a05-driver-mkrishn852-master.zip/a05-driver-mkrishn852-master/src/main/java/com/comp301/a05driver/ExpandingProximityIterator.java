package com.comp301.a05driver;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ExpandingProximityIterator implements Iterator<Driver> {
    private Iterator<Driver> iterator;
    private Position clientPosition;
    int expansionStep;
    private Iterable<Driver> driverPool;
    private Driver nextDriver;
    private boolean outOfBounds;
    private int rings;

    public ExpandingProximityIterator(Iterable<Driver> driverPool, Position clientPosition, int expansionStep) {
        if ((driverPool == null) || (clientPosition == null) || (expansionStep <= 0)) {
            throw new IllegalArgumentException();
        }
        this.iterator = driverPool.iterator();
        this.clientPosition = clientPosition;
        this.expansionStep = expansionStep;
        this.driverPool = driverPool;
        this.outOfBounds = false;
        this.rings = 0;
    }

    private void loadDriver() {
        while (nextDriver == null) {
            if (iterator.hasNext()) {
                Driver currentDriver = iterator.next();
                int distance = currentDriver.getVehicle().getPosition().getManhattanDistanceTo(clientPosition);
                if (distance > 1 + rings*expansionStep) {
                    outOfBounds = true;
                }
                else if (distance > 1 + (rings-1)*expansionStep) {
                    nextDriver = currentDriver;
                }
            }
            else if (outOfBounds ){
                outOfBounds = false;
                iterator = this.driverPool.iterator();
                rings++;
            }
            else {
                break;
            }
        }
    }

    @Override
    public boolean hasNext() {
        loadDriver();
        return nextDriver != null;
    }

    @Override
    public Driver next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        Driver localDriver = this.nextDriver;
        this.nextDriver = null;
        return localDriver;
    }
}
