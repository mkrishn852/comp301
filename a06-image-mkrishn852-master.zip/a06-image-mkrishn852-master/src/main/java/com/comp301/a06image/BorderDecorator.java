package com.comp301.a06image;

import java.awt.*;

public class BorderDecorator implements Image {
  private Image baseImage;
  private int thiccness;
  private Color borderColor;

  public BorderDecorator(Image image, int thiccness, Color borderColor) {
    if (image == null || thiccness < 0) {
      throw new IllegalArgumentException();
    }
    this.baseImage = image;
    this.thiccness = thiccness;
    this.borderColor = borderColor;
  }

  @Override
  public Color getPixelColor(int x, int y) {
    if (x < 0 || y < 0 || x >= this.getWidth() || y >= this.getHeight()) {
      throw new IllegalArgumentException();
    } else if (x < thiccness
        || x >= this.getWidth() - thiccness
        || y < thiccness
        || y >= this.getHeight() - thiccness) {

      return this.borderColor;
    } else {
      return this.baseImage.getPixelColor(x - thiccness, y - thiccness);
    }
  }

  @Override
  public int getWidth() {
    return 2 * thiccness + baseImage.getWidth();
  }

  @Override
  public int getHeight() {
    return 2 * thiccness + baseImage.getHeight();
  }

  @Override
  public int getNumLayers() {
    return this.baseImage.getNumLayers() + 1;
  }
}
