package com.comp301.a06image;

import java.awt.*;

public class CircleDecorator implements Image {
  private Image baseImage;
  private int centerX;
  private int centerY;
  private int radius;
  private Color color;

  public CircleDecorator(Image image, int cx, int cy, int radius, Color color) {
    if (radius < 0 || image == null) {
      throw new IllegalArgumentException();
    }
    this.baseImage = image;
    this.centerX = cx;
    this.centerY = cy;
    this.radius = radius;
    this.color = color;
  }

  @Override
  public Color getPixelColor(int x, int y) {
    double distance = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));
    if (x < 0 || y < 0 || distance >= radius) {
      return this.baseImage.getPixelColor(x, y);
    } else {
      return this.color;
    }
  }

  @Override
  public int getWidth() {
    return baseImage.getWidth();
  }

  @Override
  public int getHeight() {
    return baseImage.getHeight();
  }

  @Override
  public int getNumLayers() {
    return this.baseImage.getNumLayers() + 1;
  }
}
