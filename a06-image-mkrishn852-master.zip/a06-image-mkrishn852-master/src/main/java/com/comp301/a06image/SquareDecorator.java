package com.comp301.a06image;

import java.awt.*;

public class SquareDecorator implements Image {
  private Image baseImage;
  private int squareX;
  private int squareY;
  private int squareSize;
  private Color color;

  public SquareDecorator(Image image, int squareX, int squareY, int squareSize, Color color) {
    if (squareSize < 0 || image == null) {
      throw new IllegalArgumentException();
    }
    this.baseImage = image;
    this.squareX = squareX;
    this.squareY = squareY;
    this.squareSize = squareSize;
    this.color = color;
  }

  @Override
  public Color getPixelColor(int x, int y) {
    if (x < 0 || y < 0) {
      throw new IllegalArgumentException();
    }
    if ((x < this.squareX || x >= (this.squareX + this.squareSize))
        || (y < this.squareY || y >= (this.squareY + this.squareSize))) {
      return this.baseImage.getPixelColor(x, y);
    } else {
      return this.color;
    }
  }

  @Override
  public int getWidth() {
    return this.baseImage.getWidth();
  }

  @Override
  public int getHeight() {
    return this.baseImage.getHeight();
  }

  @Override
  public int getNumLayers() {
    return this.baseImage.getNumLayers() + 1;
  }
}
