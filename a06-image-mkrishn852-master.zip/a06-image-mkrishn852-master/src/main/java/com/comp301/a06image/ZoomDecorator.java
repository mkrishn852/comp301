package com.comp301.a06image;

import java.awt.*;

public class ZoomDecorator implements Image {
  private Image baseImage;
  private int multiplier;

  public ZoomDecorator(Image image, int multiplier) {
    if (image == null || multiplier <= 0) {
      throw new IllegalArgumentException();
    }
    this.baseImage = image;
    this.multiplier = multiplier;
  }

  public ZoomDecorator(Image image) {
    if (image == null) {
      throw new IllegalArgumentException();
    }
    this.baseImage = image;
    this.multiplier = 2;
  }

  @Override
  public Color getPixelColor(int x, int y) {
    if (x < 0 || y < 0 || x >= this.getWidth() || y >= this.getHeight()) {
      throw new IllegalArgumentException();
    }
    int originalX = x / multiplier;
    int originalY = y / multiplier;
    return this.baseImage.getPixelColor(originalX, originalY);
  }

  @Override
  public int getWidth() {
    return this.baseImage.getWidth() * multiplier;
  }

  @Override
  public int getHeight() {
    return this.baseImage.getHeight() * multiplier;
  }

  @Override
  public int getNumLayers() {
    return this.baseImage.getNumLayers() + 1;
  }
}
